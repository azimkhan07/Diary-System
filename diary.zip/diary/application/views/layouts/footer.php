<div class="app-wrapper-footer" style="width: 100%;">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-left">
                <div class="footer-dots">
                    <div class="dropdown">
                        <a class="dot-btn-wrapper dd-chart-btn-2" aria-haspopup="true" data-toggle="dropdown" aria-expanded="false">
                            <i class="dot-btn-icon lnr-pie-chart icon-gradient bg-love-kiss"></i>
                            <div class="badge badge-dot badge-abs badge-dot-sm badge-warning">Notifications</div>
                        </a>
                        <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu-xl rm-pointers dropdown-menu">
                            <div class="dropdown-menu-header">
                                <div class="dropdown-menu-header-inner bg-premium-dark">
                                    <div class="menu-header-image" style="background-image: url('assets/css/images/dropdown-header/abstract4.jpg');"></div>
                                    <div class="menu-header-content text-white">
                                        <h5 class="menu-header-title">Developed By</h5>
                                        <h6 class="menu-header-subtitle"><a href="#">azimkhan00798@gmail.com</a></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>