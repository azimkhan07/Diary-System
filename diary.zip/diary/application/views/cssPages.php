
<link rel="icon" href="<?php echo base_url() ?>assets/css/images/diary.png">
<link href="<?php echo base_url() ?>assets/css/main.d810cf0ae7f39f28f336.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">